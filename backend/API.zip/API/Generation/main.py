from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, EmailStr
from secrets import token_urlsafe # Generates a secure, long, random token, ideal for authentication, sessions and keys.
import sqlite3
from datetime import datetime

app = FastAPI()

# DB Setup
def init_db():
    conn = sqlite3.connect("database.db")
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            api_key TEXT UNIQUE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# Input schema
class UserRequest(BaseModel):
    email: EmailStr

# Generate secure key
def generate_api_key(length=40):
    return token_urlsafe(length)[:length]

# Endpoint to request API KEY
@app.post("/generate-key/")
def generate_key(request: UserRequest):
    email = request.email.lower()
    conn = sqlite3.connect("database.db")
    c = conn.cursor()

    # Check if it already exists
    c.execute("SELECT api_key FROM users WHERE email = ?", (email,))
    existing = c.fetchone()
    if existing:
        return {"email": email, "api_key": existing[0], "message": "You already had an API KEY"}

    # Create a new one
    new_key = generate_api_key()
    try:
        c.execute("INSERT INTO users (email, api_key) VALUES (?, ?)", (email, new_key))
        conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=500, detail="Error saving in database")
    finally:
        conn.close()

    return {"email": email, "api_key": new_key, "message": "API Key generated correctly"}